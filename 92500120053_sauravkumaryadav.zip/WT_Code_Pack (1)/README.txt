Web Technology - Combined Code Pack
==================================
This ZIP groups the Web Technology code topics we've discussed.

Folders:
1. JS_Validation/validation.html
2. Student_Registration/student_form.html
3. QNova_Admin/ (dashboard, manage questions, students, subjects/topics)
4. Labs/ (quiz app, travel itinerary, Tailwind product page, header/navbar)

How to run:
- Extract this ZIP.
- Open any .html file in VS Code or a browser.
- Most examples are standalone HTML files and use Bootstrap/Tailwind CDN links, so internet access may be needed for those styles.

Note:
These are consolidated, runnable versions of the discussed WT examples. Check any assignment-specific wording/screenshots before submission.
